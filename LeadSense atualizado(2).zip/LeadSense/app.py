from pathlib import Path
import sqlite3

from flask import Flask, jsonify, send_from_directory


PASTA_PROJETO = Path(__file__).resolve().parent
CAMINHO_BANCO = PASTA_PROJETO / "leadsense.db"

app = Flask(__name__, static_folder=None)


def conectar_banco():
    conexao = sqlite3.connect(CAMINHO_BANCO)
    conexao.row_factory = sqlite3.Row
    conexao.execute("PRAGMA foreign_keys = ON")
    return conexao


def criar_banco():
    with conectar_banco() as conexao:
        conexao.executescript("""
            CREATE TABLE IF NOT EXISTS empresas (
                id INTEGER PRIMARY KEY,
                nome TEXT NOT NULL,
                setor TEXT NOT NULL,
                porte TEXT NOT NULL,
                situacao TEXT NOT NULL,
                contexto TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS analises (
                id INTEGER PRIMARY KEY,
                empresa_id INTEGER NOT NULL UNIQUE,
                score INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
                prioridade TEXT NOT NULL
                    CHECK (prioridade IN ('Alta', 'Média', 'Baixa')),
                servico TEXT NOT NULL,
                justificativa TEXT NOT NULL,
                abordagem TEXT NOT NULL,
                origem TEXT NOT NULL DEFAULT 'demonstracao',
                criada_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (empresa_id) REFERENCES empresas(id)
            );
        """)

        empresas = [
            (
                1,
                "TechNova Soluções",
                "Tecnologia da Informação",
                "Média (50–200 func.)",
                "Crescimento Acelerado",
                "Expansão para novos mercados e necessidade de "
                "aumentar a capacidade dos sistemas."
            ),
            (
                2,
                "Logística Alpha Brasil",
                "Transporte e Logística",
                "Média (50–200 func.)",
                "Expansão Operacional",
                "Processos manuais e sistemas separados dificultam "
                "o acompanhamento das operações."
            ),
            (
                3,
                "Varejo Sul 360",
                "Varejo",
                "Grande (mais de 200 func.)",
                "Modernização Digital",
                "A empresa precisa integrar lojas, estoque e "
                "vendas digitais."
            ),
            (
                4,
                "AgroForte Inteligente",
                "Agronegócio",
                "Pequena (até 49 func.)",
                "Planejamento de Modernização",
                "A empresa pretende organizar seus investimentos "
                "em tecnologia."
            )
        ]

        analises = [
            (
                1, 1, 94, "Alta",
                "Modernização de Aplicações & Cloud",
                "Expansão recente para novos mercados. Necessidade "
                "urgente de escalabilidade.",
                "Olá, equipe TechNova! Podemos conversar sobre como "
                "modernizar suas aplicações e preparar a infraestrutura "
                "para o crescimento da empresa?"
            ),
            (
                2, 2, 82, "Média",
                "Automação e Integração de Sistemas",
                "A integração dos sistemas pode reduzir tarefas "
                "manuais e melhorar a visibilidade das operações.",
                "Olá, equipe Logística Alpha! Gostaríamos de entender "
                "seus processos e avaliar oportunidades de automação "
                "e integração dos sistemas."
            ),
            (
                3, 3, 97, "Alta",
                "Transformação Digital Completa",
                "A integração dos canais de venda e do estoque pode "
                "apoiar a modernização da operação.",
                "Olá, equipe Varejo Sul! Podemos apresentar uma "
                "proposta para integrar seus canais de venda "
                "e modernizar a operação?"
            ),
            (
                4, 4, 65, "Baixa",
                "Consultoria Estratégica em TI",
                "Um diagnóstico inicial pode ajudar a definir "
                "prioridades antes de novos investimentos.",
                "Olá, equipe AgroForte! Podemos conversar sobre "
                "um diagnóstico de tecnologia para apoiar o "
                "planejamento dos próximos investimentos?"
            )
        ]

        conexao.executemany("""
            INSERT OR IGNORE INTO empresas (
                id, nome, setor, porte, situacao, contexto
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, empresas)

        conexao.executemany("""
            INSERT OR IGNORE INTO analises (
                id, empresa_id, score, prioridade,
                servico, justificativa, abordagem
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, analises)


@app.get("/")
def inicio():
    return send_from_directory(PASTA_PROJETO, "dashboard.html")


@app.get("/dashboard.html")
def dashboard():
    return send_from_directory(PASTA_PROJETO, "dashboard.html")


@app.get("/analisar.html")
def analisar():
    return send_from_directory(PASTA_PROJETO, "analisar.html")


# Somente estes arquivos podem ser acessados pelo navegador.
@app.get("/<nome_arquivo>")
def servir_arquivo(nome_arquivo):
    arquivos_permitidos = {
        "style.css",
        "script.js",
        "analisar.css",
        "analisar.js"
    }

    if nome_arquivo not in arquivos_permitidos:
        return jsonify({"erro": "Arquivo não encontrado."}), 404

    return send_from_directory(PASTA_PROJETO, nome_arquivo)


@app.get("/api/empresas")
def listar_empresas():
    with conectar_banco() as conexao:
        empresas = conexao.execute("""
            SELECT
                empresas.id,
                empresas.nome,
                empresas.setor,
                empresas.porte,
                empresas.situacao,
                empresas.contexto,
                analises.score,
                analises.prioridade,
                analises.servico,
                analises.justificativa,
                analises.abordagem,
                analises.origem
            FROM empresas
            INNER JOIN analises
                ON analises.empresa_id = empresas.id
            ORDER BY empresas.id
        """).fetchall()

    return jsonify([dict(empresa) for empresa in empresas])


criar_banco()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)