"use strict";

// Elementos da tela.
const campoBusca = document.getElementById("buscaAnalise");
const botaoFiltro = document.getElementById("filtroAnalise");
const listaEmpresas = document.getElementById("listaEmpresas");
const estadoLista = document.getElementById("estadoLista");
const painelEmpresa = document.getElementById("painelEmpresa");
const janelaAbordagem = document.getElementById("janelaAbordagem");

let empresas = [];
let empresaSelecionada = null;
let somentePrioridadeAlta = false;


// Padroniza o texto usado na busca.
function normalizarTexto(texto) {
    return texto
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();
}


// Cria elementos sem interpretar o conteúdo como HTML.
function criarElemento(tag, classe, texto) {
    const elemento = document.createElement(tag);

    elemento.className = classe;
    elemento.textContent = texto;

    return elemento;
}


// Exibe as informações da empresa selecionada.
function mostrarEmpresa(empresa) {
    empresaSelecionada = empresa;

    document.getElementById("nomeEmpresa").textContent = empresa.nome;

    document.getElementById("resumoEmpresa").textContent =
        `${empresa.setor} • ${empresa.situacao}`;

    document.getElementById("scoreEmpresa").textContent = empresa.score;
    document.getElementById("porteEmpresa").textContent = empresa.porte;

    document.getElementById("situacaoEmpresa").textContent =
        empresa.situacao;

    document.getElementById("prioridadeEmpresa").textContent =
        empresa.prioridade;

    document.getElementById("servicoEmpresa").textContent =
        empresa.servico;

    document.getElementById("justificativaEmpresa").textContent =
        empresa.justificativa;

    painelEmpresa.hidden = false;

    listaEmpresas.querySelectorAll(".empresa-card").forEach((botao) => {
        const selecionado = Number(botao.dataset.id) === empresa.id;

        botao.classList.toggle("ativa", selecionado);
        botao.setAttribute("aria-pressed", String(selecionado));
    });
}


// Monta um cartão da lista.
function criarCartaoEmpresa(empresa) {
    const botao = document.createElement("button");

    botao.type = "button";
    botao.className = "empresa-card";
    botao.dataset.id = empresa.id;
    botao.setAttribute("aria-pressed", "false");

    const topo = criarElemento("div", "empresa-card-topo", "");
    const nome = criarElemento("strong", "", empresa.nome);

    const classeScore = empresa.prioridade === "Alta"
        ? "score-alto"
        : empresa.prioridade === "Média"
            ? "score-medio"
            : "score-baixo";

    const score = criarElemento(
        "span",
        `score ${classeScore}`,
        empresa.score
    );

    topo.append(nome, score);

    const setor = criarElemento(
        "p",
        "empresa-card-setor",
        empresa.setor
    );

    const rodape = criarElemento(
        "div",
        "empresa-card-rodape",
        ""
    );

    rodape.classList.toggle("alta", empresa.prioridade === "Alta");

    rodape.append(
        criarElemento(
            "span",
            "",
            `PRIORIDADE ${empresa.prioridade.toUpperCase()}`
        ),
        criarElemento("span", "", "›")
    );

    botao.append(topo, setor, rodape);

    botao.addEventListener("click", () => {
        mostrarEmpresa(empresa);
    });

    return botao;
}


// Atualiza a lista conforme a busca e o filtro.
function atualizarLista() {
    const busca = normalizarTexto(campoBusca.value);

    const empresasFiltradas = empresas.filter((empresa) => {
        const correspondeBusca =
            normalizarTexto(empresa.nome).includes(busca);

        const correspondePrioridade =
            !somentePrioridadeAlta || empresa.prioridade === "Alta";

        return correspondeBusca && correspondePrioridade;
    });

    listaEmpresas.replaceChildren();

    empresasFiltradas.forEach((empresa) => {
        listaEmpresas.appendChild(criarCartaoEmpresa(empresa));
    });

    estadoLista.hidden = empresasFiltradas.length > 0;
    estadoLista.textContent = "Nenhuma empresa encontrada.";

    if (empresasFiltradas.length === 0) {
        empresaSelecionada = null;
        painelEmpresa.hidden = true;
        return;
    }

    const selecaoAtual = empresasFiltradas.find((empresa) => {
        return empresa.id === empresaSelecionada?.id;
    });

    mostrarEmpresa(selecaoAtual || empresasFiltradas[0]);
}


// Busca os dados fornecidos pelo servidor Python.
async function carregarEmpresas() {
    try {
        const resposta = await fetch("/api/empresas");

        if (!resposta.ok) {
            throw new Error("Não foi possível consultar as empresas.");
        }

        empresas = await resposta.json();
        atualizarLista();
    } catch (erro) {
        estadoLista.hidden = false;
        estadoLista.textContent =
            "Não foi possível carregar os dados. Abra esta página " +
            "pelo endereço http://127.0.0.1:5000/analisar.html " +
            "com o servidor Python em execução.";

        painelEmpresa.hidden = true;
        console.error(erro);
    }
}


// Eventos de pesquisa e filtro.
campoBusca.addEventListener("input", atualizarLista);

botaoFiltro.addEventListener("click", () => {
    somentePrioridadeAlta = !somentePrioridadeAlta;

    botaoFiltro.classList.toggle("ativo", somentePrioridadeAlta);

    botaoFiltro.setAttribute(
        "aria-pressed",
        String(somentePrioridadeAlta)
    );

    const descricao = somentePrioridadeAlta
        ? "Mostrar todas as prioridades"
        : "Mostrar somente prioridade alta";

    botaoFiltro.title = descricao;
    botaoFiltro.setAttribute("aria-label", descricao);

    atualizarLista();
});


// Exibe a sugestão comercial, sem enviar mensagens.
document.getElementById("iniciarAbordagem").addEventListener(
    "click",
    () => {
        if (!empresaSelecionada) {
            return;
        }

        document.getElementById("textoAbordagem").textContent =
            empresaSelecionada.abordagem;

        janelaAbordagem.showModal();
    }
);


carregarEmpresas();