"use strict";

// Elementos utilizados na busca e no filtro.
const campoBusca = document.getElementById("buscaEmpresa");
const botaoFiltro = document.getElementById("botaoFiltro");
const linhaVazia = document.getElementById("linhaVazia");

const linhasEmpresas = document.querySelectorAll(
    "#corpoRanking tr[data-prioridade]"
);

let somentePrioridadeAlta = false;

// Permite pesquisar sem diferenciar maiúsculas e acentos.
function normalizarTexto(texto) {
    return texto
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();
}

// Aplica a pesquisa e o filtro às linhas da tabela.
function atualizarTabela() {
    const termoBusca = normalizarTexto(campoBusca.value);
    let empresasVisiveis = 0;

    linhasEmpresas.forEach(function (linha) {
        const nomeEmpresa = linha.querySelector(".nome-empresa");

        const correspondeBusca = normalizarTexto(
            nomeEmpresa.textContent
        ).includes(termoBusca);

        const correspondePrioridade =
            !somentePrioridadeAlta ||
            linha.dataset.prioridade === "alta";

        const deveExibir = correspondeBusca && correspondePrioridade;

        linha.hidden = !deveExibir;

        if (deveExibir) {
            empresasVisiveis++;
        }
    });

    linhaVazia.hidden = empresasVisiveis > 0;
}

// Ativa ou desativa o filtro de prioridade alta.
function alternarFiltro() {
    somentePrioridadeAlta = !somentePrioridadeAlta;

    botaoFiltro.classList.toggle("ativo", somentePrioridadeAlta);

    botaoFiltro.setAttribute(
        "aria-pressed",
        String(somentePrioridadeAlta)
    );

    const descricao = somentePrioridadeAlta
        ? "Mostrar todas as prioridades"
        : "Mostrar somente prioridade alta";

    botaoFiltro.title = descricao;
    botaoFiltro.setAttribute("aria-label", descricao);

    atualizarTabela();
}

// Eventos da página.
campoBusca.addEventListener("input", atualizarTabela);
botaoFiltro.addEventListener("click", alternarFiltro);